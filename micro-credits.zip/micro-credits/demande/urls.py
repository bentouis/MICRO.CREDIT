
from django.urls import path
from . import views

urlpatterns = [

    path('',views.list_demande),
    path('ajout_demande/',views.ajouter_demande,name='ajout_demande'),
    path('modifier_demande/<str:pk>',views.modifier_demande,name='modifier_demande'),
    path('supprimer_demande/<str:pk>',views.supprimer_demande,name='supprimer_demande')

]
