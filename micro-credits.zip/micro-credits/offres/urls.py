
from django.urls import path
from . import views

urlpatterns = [

    path('',views.home,name='acceuil'),
    path('ajouter_offres/', views.ajouter_offres, name='ajouter_offres'),
    path('edit/<str:pk>', views.update, name='edit_offres'),
    path('delete/<str:pk>', views.delete, name='delete_offres')

]
