from django.http import HttpResponse
from django.shortcuts import render, redirect

# Create your views here.
from demande.forms import DemandeForm
from demande.models import Demande


def list_demande(request):
    return render(request, 'demande/list_demande.html')


def ajouter_demande(request):
    form=DemandeForm()
    if request.method=='POST':
        form = DemandeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    context={'form':form}
    return render(request, 'demande/ajouter_demande.html',context)

def modifier_demande(request,pk):

    demande=Demande.objects.get(id=pk)
    form=DemandeForm(instance=demande)

    if request.method=='POST':
        form = DemandeForm(request.POST,instance=demande)
        if form.is_valid():
            form.save()
            return redirect('/')
    context={'form':form}
    return render(request, 'demande/ajouter_demande.html',context)


def supprimer_demande(request,pk):

    demande=Demande.objects.get(id=pk)

    if request.method=='POST':
         demande.delete()
         return redirect('/')
    context = {'item': demande}
    return render(request, 'demande/supprimer_demande.html',context)
