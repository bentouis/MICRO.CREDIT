from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

# Create your views here.
from client.models import Client
from decorators import allowed_users, admin_only
from demande.models import Demande
from offres.forms import OffresForm
from offres.models import Offres



@login_required(login_url='login')
@admin_only

def home(request):

    demandes=Demande.objects.all()
    clients=Client.objects.all()
    offres = Offres.objects.all()
    context= {'demandes':demandes,'clients':clients,'offres': offres}
    return render(request,'offres/acceuil.html',context)





@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def ajouter_offres(request):
    form=OffresForm()
    if request.method=='POST':
        form = OffresForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    context={'form':form}
    return render(request, 'demande/ajouter_demande.html',context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def edit(request, id):
    client = Client.objects.get(id=id)
    return render(request,'client/edit.html', {'edit':edit})

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def update(request, pk):

    offres = Offres.objects.get(id=pk)
    form = OffresForm(instance=offres)

    if request.method == 'POST':
        form = OffresForm(request.POST, instance=offres)
        if form.is_valid():
            form.save()
            return redirect('/')
    context = {'form': form}
    return render(request, 'offres/edit.html', context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def delete(request,pk):

    offres=Offres.objects.get(id=pk)

    if request.method=='POST':
         offres.delete()
         return redirect('/')
    context = {'item': offres}
    return render(request, 'offres/delete.html',context)