from django.contrib import admin
from .models import Offres, Tag

# Register your models here.
admin.site.register(Offres)
admin.site.register(Tag)