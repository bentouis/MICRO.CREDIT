
from django.urls import path
from . import views

urlpatterns = [

    path('/<str:pk>',views.list_client,name='client'),
    path('ajout_client/',views.ajouter_client,name='ajout_client'),
    path('edit/<str:pk>',views.update,name='edit'),
    path('delete/<str:pk>',views.delete,name='delete')

]
