from django.db import models

# Create your models here.
from client.models import Client
from offres.models import Offres


class Demande(models.Model):
    STATUS=(('en instance','en instance'),('refusé','refusé'),('valider','valider'))
    client=models.ForeignKey(Client,null=True,on_delete=models.SET_NULL)
    offres=models.ForeignKey(Offres,null=True,on_delete=models.SET_NULL)
    status=models.CharField(max_length=333, null=True,choices=STATUS)
    date_creation = models.DateTimeField(auto_now_add=True, null=True)



