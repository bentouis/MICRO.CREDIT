from django.forms import ModelForm
from .models import Demande

class DemandeForm(ModelForm):
      class Meta:
          model=Demande
          fields="__all__"
