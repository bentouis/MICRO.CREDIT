import django_filters
from .models import Demande
class DemadeFilter(django_filters.FilterSet):
    class Meta:
        model=Demande
        fields='__all__'
        exclude=['client','date_creation']


