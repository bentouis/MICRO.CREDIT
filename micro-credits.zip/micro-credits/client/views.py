from django.http import HttpResponse
from django.shortcuts import render, redirect
from client.models import Client
from .forms import ClientForm
from .models import Client
from demande.filters import DemadeFilter

def list_client(request,pk):
    client=Client.objects.get(id=pk)
    demande=client.demande_set.all()
    demande_total = demande.count()
    MyFilter=DemadeFilter(request.GET,queryset=demande)
    demande=MyFilter.qs
    context={'client':client,'demande':demande,'demande_total':demande_total,'MyFilter':MyFilter}
    return render(request,'client/list_client.html',context)


def ajouter_client(request):
    form = ClientForm()
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    context = {'form': form}
    return render(request, 'client/ajouter_client.html', context)


def edit(request, id):
    client = Client.objects.get(id=id)
    return render(request,'client/edit.html', {'edit':edit})

def update(request, pk):

    client = Client.objects.get(id=pk)
    form = ClientForm(instance=client)

    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            return redirect('/')
    context = {'form': form}
    return render(request, 'client/edit.html', context)


def delete(request,pk):

    client=Client.objects.get(id=pk)

    if request.method=='POST':
         client.delete()
         return redirect('/')
    context = {'item': client}
    return render(request, 'client/delete.html',context)