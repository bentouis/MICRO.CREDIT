from django.apps import AppConfig


class DemandeConfig(AppConfig):
    name = 'demande'
