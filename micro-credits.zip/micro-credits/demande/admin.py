from django.contrib import admin
from .models import Demande
# Register your models here.
admin.site.register(Demande)