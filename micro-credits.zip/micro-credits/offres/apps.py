from django.apps import AppConfig


class OffresConfig(AppConfig):
    name = 'offres'
