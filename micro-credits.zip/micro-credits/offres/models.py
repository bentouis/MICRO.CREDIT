from django.db import models

# Create your models here.

class Tag(models.Model):
    nom=models.CharField(max_length=333,null=True)

def __str__(self):
    return self.nom


class Offres(models.Model):
    NOM = (('J’ai besoin d’argent ', 'J’ai besoin d’argent '),('Je finance mon véhicule d’occasion ', 'Je finance mon véhicule d’occasion '),('Je Gère mes imprévus', 'Je Gère mes imprévus'),('Je finance mon véhicule neuf ', 'Je finance mon véhicule neuf '),('J’équipe ma maison', 'J’équipe ma maison') )
    nom=models.CharField(max_length=333,null=True,choices=NOM)
    montant=models.FloatField(null=True)
    duree=models.CharField(max_length=333,null=True)
    mensualites=models.FloatField(null=True)
    tag=models.ManyToManyField(Tag)

    def  __str__(self):
         return self.nom