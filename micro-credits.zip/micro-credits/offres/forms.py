from django.forms import ModelForm
from .models import Offres

class OffresForm(ModelForm):
      class Meta:
          model=Offres
          fields="__all__"


